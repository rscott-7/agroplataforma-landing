# Images
V24 no depende actualmente de imágenes externas para la composición principal.
Los gráficos se construyen con HTML, CSS y SVG inline.
Agregar aquí futuros assets y usar rutas relativas.
