(function(){
    var links = Array.prototype.slice.call(document.querySelectorAll('.toc a'));
    var sections = links.map(function(a){ return document.querySelector(a.getAttribute('href')); });
    if(!('IntersectionObserver' in window) || !sections.length) return;
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        var idx = sections.indexOf(entry.target);
        if(idx === -1) return;
        if(entry.isIntersecting){
          links.forEach(function(l){ l.classList.remove('active'); });
          links[idx].classList.add('active');
        }
      });
    }, { rootMargin: '-40% 0px -55% 0px', threshold: 0 });
    sections.forEach(function(s){ if(s) io.observe(s); });
  })();