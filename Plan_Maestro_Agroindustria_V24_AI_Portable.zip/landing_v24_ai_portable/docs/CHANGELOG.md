# CHANGELOG
## V24
- Basada en V22 CE03 Financiero.
- Anexo 3 FAQs movido hacia el final, después de Anexo 2.
- Anexo 3 agregado a agenda/navegación.
- 20 preguntas reorganizadas por lógica de Consejo.
- Metodología KPI renumerada como Anexo 4.
