# AI HANDOFF

## Objetivo
Continuar la edición sin perder diseño, narrativa ni estructura.

## Archivo principal
`index.html`; estilos en `css/styles.css`. La versión exacta monolítica está en
`docs/SOURCE_SINGLE_FILE_V24.html`.

## Reglas
- No inventar cifras.
- Si falta un dato: `Por validar`, `En evaluación` o `En construcción`.
- No confundir fondeo potencial con aprobado.
- No confundir pipeline con cartera desembolsada.
- No confundir economics brutos / contribución pre-OPEX con utilidad neta.
- Mantener estatus: EJECUTADO / APROBADO / EN EVALUACIÓN / PILOTO / TESIS ESTRATÉGICA.
- Mantener: pilares estratégicos, semáforo por pilar, META AGROINDUSTRIAL y GOBERNANZA Semanal.

## CE03
`24% yield + 1.5% comisión - 11% fondeo - 3% pérdida esperada = ≈11.5% antes de OPEX`.
Sobre $100 MDP: `$24M + $1.5M - $11M - $3M = ≈$11.5M antes de OPEX`.
OPEX real está por validar. Recalibrar economics al menos mensualmente.
Siguiente nivel: OPEX real + capital económico + RAROC.

## Anexo 3
Debe permanecer hacia el final y seguir:
Tesis → Economics → Riesgo → Ejecución → Gobernanza.
